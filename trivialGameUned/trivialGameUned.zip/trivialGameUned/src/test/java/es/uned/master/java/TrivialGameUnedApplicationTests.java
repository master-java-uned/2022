package es.uned.master.java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrivialGameUnedApplicationTests {

	@Test
	void contextLoads() {
	}

}
