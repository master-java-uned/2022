package es.uned.master.java.models;

public enum ECategoria {
	HARRY_POTTER,
	STAR_WARS,
	NARNIA,
	SEÑOR_ANILLOS,
	MARVEL,
	DISNEY,
	DADO
}
